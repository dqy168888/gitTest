/**
 * Created by GZW on 2015/9/14.
 */
var t = (new Date()).getTime();
function loadStyles(url) {
    var link = document.createElement('link');link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = url+"?"+t;
    document.getElementsByTagName('head')[0].appendChild(link);
}
function loadScript(url,fn) {
    var script = document.createElement('script');
    script.type = 'text/javascript';
    //是否js文件
    var isJs = /(\.js)$/.exec(url);
    if (script.readyState) {
        script.onreadystatechange = function () {
            if (script.readyState == 'loaded' || script.readyState == 'complete') {
                script.onreadystatechange = null;
                fn instanceof Function && fn.call();
                !isJs && script.parentNode.removeChild(script);
            }
        };
    }
    else {
        script.onload = function () {
            fn instanceof Function && fn.call();
            !isJs && script.parentNode.removeChild(script);
        };
    }
    script.src = encodeURI(url+"?"+t);
    document.getElementsByTagName('head')[0].appendChild(script);
}
